@echo off
chcp 65001 >nul

echo.
echo ========= REMOTEPOWER V2 (V1.6) 전체 자동 설치 시작 =========
echo.

REM --- 관리자 권한 확인 ---
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo 관리자 권한으로 다시 실행합니다...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

REM --- 폴더 경로 설정 ---
set ROOT_DIR=%~dp0
set SERVICE_EXE=%ROOT_DIR%RemotePowerService\RemotePowerService.exe
set STATE_EXE=%ROOT_DIR%RemoteState\RemoteState.exe
set STARTUP_FOLDER=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup
set SHORTCUT_PATH=%STARTUP_FOLDER%\RemoteState.lnk

echo 설치 폴더            : %ROOT_DIR%
echo RemotePowerService   : %SERVICE_EXE%
echo RemoteState          : %STATE_EXE%
echo 시작프로그램 경로   : %SHORTCUT_PATH%
echo.

REM ================================================================
REM [1] RemotePowerService.exe 서비스 등록
REM ================================================================
echo [1/4] RemotePowerService Windows 서비스 등록...

if not exist "%SERVICE_EXE%" (
    echo [오류] %SERVICE_EXE% 파일이 없습니다.
    pause
    exit /b
)

REM 기존 서비스 있으면 제거
sc query RemotePowerServiceV2 >nul 2>&1
if %errorlevel%==0 (
    sc stop RemotePowerServiceV2 >nul 2>&1
    sc delete RemotePowerServiceV2 >nul 2>&1
    echo 기존 서비스 삭제 완료
)

REM 새 서비스 설치
"%SERVICE_EXE%" install

REM 서비스 자동 시작 설정
sc config RemotePowerServiceV2 start= auto >nul

REM 서비스 시작
sc start RemotePowerServiceV2

echo RemotePowerService 서비스 등록 & 시작 완료
echo.

REM ================================================================
REM [2] RemoteState.exe 시작프로그램 등록
REM ================================================================
echo [2/4] RemoteState 시작프로그램 등록...

if not exist "%STATE_EXE%" (
    echo [오류] %STATE_EXE% 파일이 없습니다.
    pause
    exit /b
)

powershell -Command ^
 "$s=(New-Object -COM WScript.Shell).CreateShortcut('%SHORTCUT_PATH%');" ^
 "$s.TargetPath='%STATE_EXE%';" ^
 "$s.WorkingDirectory='%ROOT_DIR%RemoteState';" ^
 "$s.IconLocation='%STATE_EXE%';" ^
 "$s.Save();"

echo RemoteState.lnk 생성 완료
echo.

REM ================================================================
REM [3] Windows 방화벽 포트 설정
REM ================================================================
echo [3/4] Windows 포트 자동 허용 설정...

netsh advfirewall firewall add rule name="RemotePower_5050"  dir=in action=allow protocol=TCP localport=5050
netsh advfirewall firewall add rule name="RemoteState_5051"  dir=in action=allow protocol=TCP localport=5051
netsh advfirewall firewall add rule name="TCPBTN_6000"       dir=in action=allow protocol=TCP localport=6000
netsh advfirewall firewall add rule name="TCPBTN_6001"       dir=in action=allow protocol=TCP localport=6001
netsh advfirewall firewall add rule name="OSC_7000"          dir=in action=allow protocol=UDP localport=7000
netsh advfirewall firewall add rule name="OSC_7001"          dir=in action=allow protocol=UDP localport=7001
netsh advfirewall firewall add rule name="Remote_9999"       dir=in action=allow protocol=TCP localport=9999
netsh advfirewall firewall add rule name="ZeroTier_9993"     dir=in action=allow protocol=UDP localport=9993

echo 포트 설정 완료 (5050,5051 / 6000,6001 / 7000,7001 / 9999 / 9993)
echo.

REM ================================================================
REM [4] 최종 확인 안내
REM ================================================================
echo [4/4] 설치 완료 요약:
echo  - RemotePowerServiceV2 : Windows 서비스 (부팅 문제 없이 항상 실행됨)
echo  - RemoteState.exe      : Logon 이후 트레이에 표시
echo  - 포트 설정            : 모두 허용됨
echo.
echo ========= 설치 완료! PC 재부팅 후 정상 작동 확인하세요 =========
pause
