[CmdletBinding()]
param(
    [ValidateSet('Plan','Prepare','Configure','Install','Uninstall')][string]$Mode = 'Plan',
    [string]$SourceDir = $PSScriptRoot,
    [string]$TargetDir = '',
    [string]$AllowedRemote = 'LocalSubnet',
    [ValidateSet('Yes','No')][string]$CompatibilityPorts = 'Yes',
    [switch]$LaunchState,
    [switch]$LibraryOnly
)

$ErrorActionPreference = 'Stop'
$ServiceName = 'RemotePowerServiceV2' # Preserve legacy service identity on upgrade.
$RuleGroup = 'CreDL RemotePower V3'
$DataRoot = Join-Path $env:ProgramData 'CreDL\RemotePower'
$PackageFiles = @('RemotePowerService\RemotePowerService.exe','RemoteState\RemoteState.exe','RemotePower.ico','install-helper.ps1','install_all.bat','uninstall_all.bat','Test-RemotePower.ps1','TESTING-KO.txt','BUILD-RESULTS.txt','THIRD-PARTY-LICENSES.txt','SHA256SUMS.txt')

function Get-AllowedAddresses([string]$Value) {
    if ($Value -eq 'LocalSubnet') { return @('LocalSubnet') }
    $addresses = @()
    foreach ($entry in $Value.Split(',')) {
        $entry = $entry.Trim()
        if ($entry -notmatch '^(\d{1,3}\.){3}\d{1,3}(/\d{1,2})?$') { throw 'Use LocalSubnet or IPv4/CIDR addresses separated by commas.' }
        $parts = $entry.Split('/')
        $ip = $null
        if (-not [Net.IPAddress]::TryParse($parts[0], [ref]$ip) -or $ip.AddressFamily -ne 'InterNetwork') { throw "Invalid IPv4 address: $entry" }
        if ($parts.Count -eq 2 -and [int]$parts[1] -gt 32) { throw "Invalid CIDR: $entry" }
        $addresses += $entry
    }
    if ($addresses.Count -eq 0) { throw 'No allowed addresses.' }
    return $addresses
}

function Get-PortPlan([bool]$Compatibility) {
    @(
        [pscustomobject]@{Name='CreDL-RP3-TCP-5050'; Protocol='TCP'; Port=5050; Program='RemotePowerService\RemotePowerService.exe'}
        [pscustomobject]@{Name='CreDL-RP3-TCP-5051'; Protocol='TCP'; Port=5051; Program='RemoteState\RemoteState.exe'}
    )
    if ($Compatibility) {
        foreach ($port in @(6000,6001,9999)) { [pscustomobject]@{Name="CreDL-RP3-TCP-$port";Protocol='TCP';Port=$port;Program=''} }
        foreach ($port in @(7000,7001,9001)) { [pscustomobject]@{Name="CreDL-RP3-UDP-$port";Protocol='UDP';Port=$port;Program=''} }
    }
}

function Get-LegacyRuleNames([bool]$Compatibility) {
    @('RemotePower_5050','RemoteState_5051','CreDL RemotePower Service TCP 5050','CreDL RemoteState TCP 5051')
    if ($Compatibility) {
        @('TCPBTN_6000','TCPBTN_6001','OSC_7000','OSC_7001','Remote_9999','OSCin_9001',
          'CreDL TotalScheduler TCP Button 6000','CreDL TotalScheduler TCP Button 6001',
          'CreDL TotalScheduler Remote TCP 9999','CreDL TotalScheduler OSC UDP 7000',
          'CreDL TotalScheduler OSC UDP 7001','CreDL TotalScheduler OSC Input UDP 9001')
    }
    # ZeroTier_9993 belongs to the VPN, not this service; do not remove it.
}

function Get-ServiceExecutable([string]$ImagePath) {
    if ($ImagePath -match '^\s*"([^"]+\.exe)"') { return [IO.Path]::GetFullPath($Matches[1]) }
    if ($ImagePath -match '^\s*(.+?\.exe)(\s|$)') { return [IO.Path]::GetFullPath($Matches[1]) }
    throw 'Cannot safely parse the existing service executable path.'
}

function Get-ExistingService { Get-CimInstance Win32_Service -Filter "Name='$ServiceName'" }

function Get-ManagedPaths([string]$Destination) {
    $paths = @((Join-Path $Destination 'RemotePowerService\RemotePowerService.exe'), (Join-Path $Destination 'RemoteState\RemoteState.exe'))
    $service = Get-ExistingService
    if ($service) {
        $oldExe = Get-ServiceExecutable $service.PathName
        if ([IO.Path]::GetFileName($oldExe) -ine 'RemotePowerService.exe') { throw 'Existing service points to an unexpected executable. Manual review required.' }
        $paths += $oldExe
        $oldRoot = Split-Path (Split-Path $oldExe -Parent) -Parent
        $paths += Join-Path $oldRoot 'RemoteState\RemoteState.exe'
    }
    return @($paths | Select-Object -Unique)
}

function Assert-InstallTarget([string]$Path) {
    $full = [IO.Path]::GetFullPath($Path).TrimEnd('\')
    if ($full -eq [IO.Path]::GetPathRoot($full).TrimEnd('\') -or $full -in @($env:USERPROFILE,$env:WINDIR,$env:ProgramFiles,${env:ProgramFiles(x86)})) {
        throw 'Choose a dedicated RemotePower installation directory.'
    }
    if ($full.StartsWith('\\')) { throw 'Install on a local drive, not a network share.' }
    return $full
}

function Backup-Installation([string]$Destination) {
    $backup = Join-Path $DataRoot ('backups\' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff') + '-' + [guid]::NewGuid().ToString('N').Substring(0,8))
    New-Item -ItemType Directory -Path $backup -Force | Out-Null
    $files = @()
    foreach ($file in (Get-ManagedPaths $Destination)) {
        if (Test-Path -LiteralPath $file -PathType Leaf) {
            $copy = Join-Path $backup (('{0:D2}-' -f $files.Count) + [IO.Path]::GetFileName($file))
            Copy-Item -LiteralPath $file -Destination $copy
            $files += [pscustomobject]@{Original=$file;Backup=$copy;SHA256=(Get-FileHash -LiteralPath $copy).Hash}
        }
    }
    $service = Get-ExistingService
    $key = "HKLM:\SYSTEM\CurrentControlSet\Services\$ServiceName"
    $environment = @((Get-ItemProperty -LiteralPath $key -Name Environment -ErrorAction SilentlyContinue).Environment)
    $ruleSnapshot = @()
    $names = @(Get-LegacyRuleNames $true)
    foreach ($rule in @(Get-NetFirewallRule -PolicyStore PersistentStore | Where-Object { $_.Group -eq $RuleGroup -or $_.DisplayName -in $names })) {
        $ruleSnapshot += [pscustomobject]@{Rule=$rule;Ports=($rule | Get-NetFirewallPortFilter);Addresses=($rule | Get-NetFirewallAddressFilter);Application=($rule | Get-NetFirewallApplicationFilter)}
    }
    $ruleSnapshot | Export-Clixml -LiteralPath (Join-Path $backup 'firewall-before.xml')
    [pscustomobject]@{Files=$files;Service=$service;Environment=$environment;Target=$Destination;Created=(Get-Date).ToString('o')} |
        ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $backup 'backup.json') -Encoding UTF8
    $backup | Set-Content -LiteralPath (Join-Path $DataRoot 'last-backup.txt') -Encoding UTF8
    Write-Host "Backup: $backup"
    return $backup
}

function Stop-ManagedApplications([string]$Destination) {
    $paths = @(Get-ManagedPaths $Destination)
    $service = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
    if ($service -and $service.Status -ne 'Stopped') {
        Stop-Service -Name $ServiceName -ErrorAction Stop
        $service.WaitForStatus('Stopped', [TimeSpan]::FromSeconds(30))
    }
    foreach ($process in @(Get-CimInstance Win32_Process -Filter "Name='RemoteState.exe'")) {
        if ($process.ExecutablePath -and $process.ExecutablePath -in $paths) {
            Stop-Process -Id $process.ProcessId -Force -ErrorAction Stop
            Wait-Process -Id $process.ProcessId -Timeout 10 -ErrorAction SilentlyContinue
        }
    }
}

function Update-StartupShortcut([string]$Destination, [string]$Backup) {
    $shell = New-Object -ComObject WScript.Shell
    $managed = @(Get-ManagedPaths $Destination)
    if ($Backup -and (Test-Path -LiteralPath (Join-Path $Backup 'backup.json'))) {
        $manifest = Get-Content -LiteralPath (Join-Path $Backup 'backup.json') -Raw | ConvertFrom-Json
        $managed += @($manifest.Files | ForEach-Object { $_.Original })
    }
    # Remove only this application's old shortcuts, not unrelated startup items.
    foreach ($profile in @(Get-CimInstance Win32_UserProfile | Where-Object { -not $_.Special -and $_.LocalPath })) {
        $link = Join-Path $profile.LocalPath 'AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\RemoteState.lnk'
        if (Test-Path -LiteralPath $link) {
            $old = $shell.CreateShortcut($link)
            if ($old.TargetPath -in $managed) {
                if ($Backup) { Copy-Item -LiteralPath $link -Destination (Join-Path $Backup ('startup-' + [guid]::NewGuid().ToString('N') + '.lnk')) }
                Remove-Item -LiteralPath $link -Force
            }
        }
    }
    $commonLink = Join-Path ([Environment]::GetFolderPath('CommonStartup')) 'RemoteState.lnk'
    if ($Backup -and (Test-Path -LiteralPath $commonLink)) {
        Copy-Item -LiteralPath $commonLink -Destination (Join-Path $Backup 'common-startup-RemoteState.lnk')
    }
    $shortcut = $shell.CreateShortcut($commonLink)
    $shortcut.TargetPath = Join-Path $Destination 'RemoteState\RemoteState.exe'
    $shortcut.WorkingDirectory = Join-Path $Destination 'RemoteState'
    $shortcut.IconLocation = Join-Path $Destination 'RemotePower.ico'
    $shortcut.Save()
}

function Set-ManagedFirewall([string]$Destination, [string[]]$Addresses, [bool]$Compatibility) {
    foreach ($entry in @(Get-PortPlan $Compatibility)) {
        $parameters = @{DisplayName=$entry.Name;Group=$RuleGroup;Direction='Inbound';Action='Allow';Enabled='True';Profile='Any';Protocol=$entry.Protocol;LocalPort=$entry.Port;RemoteAddress=$Addresses;EdgeTraversalPolicy='Block'}
        if ($entry.Program) { $parameters.Program = Join-Path $Destination $entry.Program }
        $existing = Get-NetFirewallRule -Name $entry.Name -ErrorAction SilentlyContinue
        if ($existing) {
            if ($existing.Group -ne $RuleGroup) { throw "Firewall rule name belongs to another group: $($entry.Name)" }
            # DisplayName/Group are selectors, not writable properties in Set's Name parameter set.
            $parameters.Remove('DisplayName'); $parameters.Remove('Group')
            $parameters.NewDisplayName = $entry.Name
            Set-NetFirewallRule -Name $entry.Name @parameters | Out-Null
        }
        else { New-NetFirewallRule -Name $entry.Name @parameters | Out-Null }
    }
    # Remove only known legacy rules AFTER new rules have been created successfully.
    foreach ($displayName in @(Get-LegacyRuleNames $true)) {
        Get-NetFirewallRule -DisplayName $displayName -ErrorAction SilentlyContinue | Remove-NetFirewallRule
    }
    if (-not $Compatibility) {
        foreach ($entry in @(Get-PortPlan $true | Where-Object { -not $_.Program })) {
            Get-NetFirewallRule -Name $entry.Name -ErrorAction SilentlyContinue | Remove-NetFirewallRule
        }
    }
}

function Assert-ServiceVersion {
    # Read-only capability query. NEVER send shutdown or reboot here.
    $client = New-Object Net.Sockets.TcpClient
    try {
        $pending = $client.BeginConnect('127.0.0.1',5050,$null,$null)
        if (-not $pending.AsyncWaitHandle.WaitOne(1500)) { throw 'Local diagnostic connection timed out.' }
        $client.EndConnect($pending)
        $stream = $client.GetStream()
        $stream.ReadTimeout = 1500; $stream.WriteTimeout = 1500
        $request = [Text.Encoding]::ASCII.GetBytes("GET_CAPABILITIES`r`n")
        $stream.Write($request,0,$request.Length)
        $client.Client.Shutdown([Net.Sockets.SocketShutdown]::Send)
        $buffer = New-Object byte[] 4096
        $data = New-Object IO.MemoryStream
        $deadline = [DateTime]::UtcNow.AddSeconds(2)
        do {
            if ([DateTime]::UtcNow -gt $deadline) { throw 'Capability response timed out.' }
            $length = $stream.Read($buffer,0,$buffer.Length)
            if ($length -eq 0) { break }
            $data.Write($buffer,0,$length)
            if ($data.Length -gt 65536) { throw 'Capability response too large.' }
        } while ($buffer[0..($length-1)] -notcontains 10)
        $response = [Text.Encoding]::UTF8.GetString($data.ToArray()) | ConvertFrom-Json
        if ($response.agent_version -ne '3.0.0' -or $response.protocol_version -ne 1) { throw 'Port 5050 is not the expected V3.0 diagnostic service.' }
    } finally { $client.Close() }
}

function Set-ServiceRegistration([string]$Exe) {
    $existing = Get-ExistingService
    if ($existing) {
        # CIM preserves the quotes around paths with spaces without native-shell argument parsing.
        $result = Invoke-CimMethod -InputObject $existing -MethodName Change -Arguments @{
            PathName=('"' + $Exe + '"'); StartMode='Automatic'; DisplayName='Remote Power Service V3.0'; StartName=$existing.StartName
        }
        if ($result.ReturnValue -ne 0) { throw "Service configuration failed (code $($result.ReturnValue))." }
    } else {
        New-Service -Name $ServiceName -BinaryPathName ('"' + $Exe + '"') -DisplayName 'Remote Power Service V3.0' -StartupType Automatic | Out-Null
    }
}

function Configure-Installation([string]$Destination, [string[]]$Addresses, [bool]$Compatibility) {
    $exe = Join-Path $Destination 'RemotePowerService\RemotePowerService.exe'
    foreach ($file in @($exe, (Join-Path $Destination 'RemoteState\RemoteState.exe'))) {
        if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { throw "Missing installed file: $file" }
    }
    Set-ServiceRegistration $exe
    $key = "HKLM:\SYSTEM\CurrentControlSet\Services\$ServiceName"
    $environment = @((Get-ItemProperty -LiteralPath $key -Name Environment -ErrorAction SilentlyContinue).Environment | Where-Object { $_ -and $_ -notlike 'REMOTEPOWER_DIAGNOSTIC_ALLOW_CIDRS=*' })
    if ($Addresses -notcontains 'LocalSubnet') {
        $environment += 'REMOTEPOWER_DIAGNOSTIC_ALLOW_CIDRS=127.0.0.1/32,' + ($Addresses -join ',')
    }
    if ($environment.Count) { New-ItemProperty -LiteralPath $key -Name Environment -PropertyType MultiString -Value $environment -Force | Out-Null }
    else { Remove-ItemProperty -LiteralPath $key -Name Environment -ErrorAction SilentlyContinue }
    Set-ManagedFirewall $Destination $Addresses $Compatibility
    $backup = ''
    if (Test-Path -LiteralPath (Join-Path $DataRoot 'last-backup.txt')) { $backup = (Get-Content -LiteralPath (Join-Path $DataRoot 'last-backup.txt') -Raw).Trim() }
    Update-StartupShortcut $Destination $backup
    Start-Service -Name $ServiceName
    (Get-Service $ServiceName).WaitForStatus('Running', [TimeSpan]::FromSeconds(20))
    $verified = $false
    for ($attempt=0; $attempt -lt 5; $attempt++) {
        try { Assert-ServiceVersion; $verified = $true; break } catch { Start-Sleep -Milliseconds 500 }
    }
    if (-not $verified) { throw 'Service started but V3.0 capability verification failed. Check port 5050 and setup log.' }
    Write-Host 'RemotePower V3.0 service and firewall configured. No PC reboot is performed.'
}

function Uninstall-Integration([string]$Destination) {
    $existing = Get-ExistingService
    if ($existing -and (Get-ServiceExecutable $existing.PathName) -ine (Join-Path $Destination 'RemotePowerService\RemotePowerService.exe')) {
        throw 'This uninstaller does not own the current service path. Use the current installation uninstaller.'
    }
    Stop-ManagedApplications $Destination
    if ($existing) {
        & "$env:SystemRoot\System32\sc.exe" delete $ServiceName | Out-Host
        if ($LASTEXITCODE -ne 0) { throw 'Could not remove service.' }
    }
    Get-NetFirewallRule -Group $RuleGroup -ErrorAction SilentlyContinue | Remove-NetFirewallRule
    $link = Join-Path ([Environment]::GetFolderPath('CommonStartup')) 'RemoteState.lnk'
    if (Test-Path -LiteralPath $link) {
        $shell = New-Object -ComObject WScript.Shell
        if ($shell.CreateShortcut($link).TargetPath -ieq (Join-Path $Destination 'RemoteState\RemoteState.exe')) { Remove-Item -LiteralPath $link }
    }
    Write-Host 'Integration removed. Backups are retained.'
}

if ($LibraryOnly) { return }
try {
    $addresses = @(Get-AllowedAddresses $AllowedRemote)
    if (-not $TargetDir) { $TargetDir = Join-Path $env:ProgramFiles 'TotalScheduler\RemotePower' }
    $TargetDir = Assert-InstallTarget $TargetDir
    if ($Mode -eq 'Plan') {
        Write-Output "Target: $TargetDir; Allowed remote: $($addresses -join ','); Service: $ServiceName"
        Get-PortPlan ($CompatibilityPorts -eq 'Yes') | Format-Table
        exit 0
    }
    $admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if (-not $admin) {
        $arguments = '-NoProfile -ExecutionPolicy Bypass -File "{0}" -Mode {1} -SourceDir "{2}" -TargetDir "{3}" -AllowedRemote "{4}" -CompatibilityPorts {5}' -f $PSCommandPath,$Mode,$SourceDir,$TargetDir,$AllowedRemote,$CompatibilityPorts
        $process = Start-Process -FilePath "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList $arguments -Verb RunAs -WindowStyle Hidden -Wait -PassThru
        if ($process.ExitCode -ne 0) { throw "Elevated setup failed (exit $($process.ExitCode)). See $DataRoot\setup.log" }
        if ($LaunchState -and $Mode -eq 'Install') { Start-Process -FilePath (Join-Path $TargetDir 'RemoteState\RemoteState.exe') -WindowStyle Hidden }
        exit 0
    }
    New-Item -ItemType Directory -Path $DataRoot -Force | Out-Null
    Start-Transcript -Path (Join-Path $DataRoot 'setup.log') -Append | Out-Null
    if ($Mode -in @('Prepare','Install')) {
        if ($Mode -eq 'Install') {
            foreach ($relative in $PackageFiles) {
                if (-not (Test-Path -LiteralPath (Join-Path $SourceDir $relative) -PathType Leaf)) { throw "Missing package file: $relative" }
            }
        }
        $null = Backup-Installation $TargetDir
        Stop-ManagedApplications $TargetDir
    }
    if ($Mode -eq 'Install') {
        foreach ($relative in $PackageFiles) {
            $source = [IO.Path]::GetFullPath((Join-Path $SourceDir $relative))
            $destination = Join-Path $TargetDir $relative
            if ($source -ine $destination) {
                New-Item -ItemType Directory -Path (Split-Path $destination -Parent) -Force | Out-Null
                Copy-Item -LiteralPath $source -Destination $destination -Force
            }
        }
    }
    if ($Mode -in @('Install','Configure')) { Configure-Installation $TargetDir $addresses ($CompatibilityPorts -eq 'Yes') }
    if ($Mode -eq 'Uninstall') { Uninstall-Integration $TargetDir }
    Stop-Transcript | Out-Null
    if ($LaunchState -and $Mode -eq 'Install') { Start-Process -FilePath (Join-Path $TargetDir 'RemoteState\RemoteState.exe') -WindowStyle Hidden }
    exit 0
} catch {
    Write-Host ('ERROR: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host "See $DataRoot\setup.log. Existing EXE backups are in $DataRoot\backups. No automatic PC reboot is performed."
    try { Stop-Transcript | Out-Null } catch {}
    exit 1
}
