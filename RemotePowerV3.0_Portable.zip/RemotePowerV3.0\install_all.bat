@echo off
setlocal
title RemotePower V3.0 Setup
REM Optional first argument: Scheduler IPv4/CIDR, or LocalSubnet (default).
set "RP_ALLOWED=LocalSubnet"
if not "%~1"=="" set "RP_ALLOWED=%~1"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-helper.ps1" -Mode Install -SourceDir "%~dp0." -AllowedRemote "%RP_ALLOWED%" -CompatibilityPorts Yes -LaunchState
set "RP_RESULT=%errorlevel%"
if not "%RP_RESULT%"=="0" echo Installation failed. Read the error above and the setup log.
pause
exit /b %RP_RESULT%
