param([string]$Computer = '127.0.0.1', [int]$CommandPort = 5050, [int]$StatePort = 5051)
$ErrorActionPreference = 'Stop'
# This script has no power-command path. It only reads capabilities/diagnostics/pong.
function Read-Reply([int]$Port, [string]$Request) {
    $client = New-Object Net.Sockets.TcpClient
    try {
        $pending = $client.BeginConnect($Computer,$Port,$null,$null)
        if (-not $pending.AsyncWaitHandle.WaitOne(2000)) { throw "Connection timeout: ${Computer}:$Port" }
        $client.EndConnect($pending)
        $stream = $client.GetStream()
        $stream.ReadTimeout = 2000; $stream.WriteTimeout = 2000
        $bytes = [Text.Encoding]::ASCII.GetBytes($Request + "`r`n")
        $stream.Write($bytes,0,$bytes.Length)
        $client.Client.Shutdown([Net.Sockets.SocketShutdown]::Send)
        $result = New-Object IO.MemoryStream
        $buffer = New-Object byte[] 4096
        $deadline = [DateTime]::UtcNow.AddSeconds(3)
        do {
            if ([DateTime]::UtcNow -gt $deadline) { throw 'Response time limit reached.' }
            $count = $stream.Read($buffer,0,$buffer.Length)
            if ($count -eq 0) { break }
            $result.Write($buffer,0,$count)
            if ($result.Length -gt 65536) { throw 'Response too large.' }
        } while ($buffer[0..($count-1)] -notcontains 10)
        return [Text.Encoding]::UTF8.GetString($result.ToArray()).Trim()
    } finally { $client.Close() }
}
try {
    $capabilities = Read-Reply $CommandPort 'GET_CAPABILITIES' | ConvertFrom-Json
    $capabilities | Format-List
    if ($capabilities.protocol_version -ne 1 -or $capabilities.capabilities -notcontains 'diagnostics_v1') { throw 'Unsupported diagnostic protocol.' }
    $diagnostics = Read-Reply $CommandPort 'GET_DIAGNOSTICS' | ConvertFrom-Json
    $diagnostics | Format-List
    try {
        $pong = Read-Reply $StatePort 'ping'
        Write-Host "RemoteState ${StatePort}: $pong"
        if ($pong -ne 'pong') { throw 'Unexpected state response.' }
    } catch {
        Write-Warning ('RemotePowerService answered, but RemoteState is unavailable: ' + $_.Exception.Message)
        exit 2
    }
    Write-Host 'Read-only checks passed. No power command was sent.'
    exit 0
} catch { Write-Error $_; exit 1 }
