@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-helper.ps1" -Mode Uninstall -TargetDir "%~dp0."
set "RP_RESULT=%errorlevel%"
echo Program files and backups are kept. No PC shutdown or reboot was requested.
pause
exit /b %RP_RESULT%
