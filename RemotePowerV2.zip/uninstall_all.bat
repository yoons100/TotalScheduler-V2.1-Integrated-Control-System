@echo off
chcp 65001 >nul

echo.
echo ========= REMOTEPOWER V2 전체 삭제 시작 =========
echo.

REM 관리자 권한 확인
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo 관리자 권한으로 다시 실행합니다...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

REM 1) Windows 서비스(RemotePowerServiceV2) 삭제
echo [1/3] 서비스 삭제...
sc stop RemotePowerServiceV2 >nul 2>&1
sc delete RemotePowerServiceV2 >nul 2>&1

REM 2) RemoteState 시작프로그램 삭제
echo [2/3] 시작프로그램 정리...
set STARTUP_FOLDER=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup
del "%STARTUP_FOLDER%\RemoteState.lnk" >nul 2>&1

REM 3) 방화벽 규칙 삭제
echo [3/3] 방화벽 포트 규칙 삭제...
netsh advfirewall firewall delete rule name="RemotePower_5050" >nul
netsh advfirewall firewall delete rule name="RemoteState_5051" >nul
netsh advfirewall firewall delete rule name="TCPBTN_6000" >nul
netsh advfirewall firewall delete rule name="TCPBTN_6001" >nul
netsh advfirewall firewall delete rule name="OSC_7000" >nul
netsh advfirewall firewall delete rule name="OSC_7001" >nul
netsh advfirewall firewall delete rule name="Remote_9999" >nul
netsh advfirewall firewall delete rule name="ZeroTier_9993" >nul

echo.
echo ========= 전체 삭제 완료! =========
pause
